<div align="center">

![Operating Systems Lab banner](https://capsule-render.vercel.app/api?type=waving&color=0:171717,55:7C2D12,100:E95420&height=180&section=header&text=OPERATING%20SYSTEMS%20LAB&fontSize=32&fontColor=ffffff)

# ◈ EXPERIMENT 01
### Installation and Configuration of Oracle VirtualBox & Ubuntu Linux

![Lab](https://img.shields.io/badge/LAB-Operating%20Systems-292524?style=for-the-badge)
![VirtualBox](https://img.shields.io/badge/VirtualBox-Hypervisor-9A3412?style=for-the-badge&logo=virtualbox&logoColor=white)
![Ubuntu](https://img.shields.io/badge/Ubuntu-Linux-E95420?style=for-the-badge&logo=ubuntu&logoColor=white)
![Bash](https://img.shields.io/badge/Bash-System%20Verification-292524?style=for-the-badge&logo=gnubash&logoColor=white)

**Virtualization · Linux Installation · System Administration**

[Overview](#overview) · [Procedure](#procedure) · [Implementation](#implementation) · [Results](#results)

</div>

---

## Table of Contents

1. [Overview](#overview)
2. [Aim and Objectives](#aim-and-objectives)
3. [Theory](#theory)
4. [Requirements](#requirements)
5. [System Architecture](#system-architecture)
6. [Procedure](#procedure)
7. [Implementation](#implementation)
8. [Screenshot Documentation](#screenshot-documentation)
9. [Experimental Observations](#experimental-observations)
10. [Results](#results)
11. [Troubleshooting](#troubleshooting)
12. [Conclusion](#conclusion)
13. [Repository Structure](#repository-structure)
14. [References](#references)

## Overview

This experiment demonstrates the installation of Oracle VirtualBox, creation of a virtual machine (VM), installation of Ubuntu Linux, and verification of the guest environment using Linux terminal commands.

| Laboratory detail | Value |
| :--- | :--- |
| Experiment | 01 |
| Subject | Operating Systems Laboratory |
| Student | [Enter name] |
| Roll number | [Enter roll number] |
| Date | [Enter experiment date] |
| Host OS | [Enter host operating system] |
| VirtualBox version | [Enter installed version] |
| Ubuntu release | [Enter installed release] |

## Aim and Objectives

**Aim:** To install Oracle VirtualBox, create and configure a virtual machine, and install Ubuntu Linux in a virtualized environment.

- Understand host and guest operating systems.
- Configure virtual CPU, RAM, storage and networking.
- Install Ubuntu from a bootable ISO image.
- Execute Linux commands to inspect system resources and configuration.
- Document actual installation and verification evidence.

## Theory

Virtualization allows a computer to run a guest operating system using virtual hardware. Oracle VirtualBox is a hosted (Type 2) hypervisor that runs on a supported host operating system and provides virtual hardware to guest systems.

| Concept | Description |
| :--- | :--- |
| Host OS | Operating system running on the physical computer. |
| Guest OS | Operating system installed inside the VM. |
| Hypervisor | Software that manages virtual machines and their resources. |
| ISO image | Disk image containing Ubuntu installation media. |
| VDI | VirtualBox virtual disk image format. |
| NAT | Default-style networking option that commonly permits guest outbound connectivity through the host. |
| Linux kernel | Core component managing processes, memory, devices and system resources. |

The guest generally reports virtual CPU, memory, disk and network devices rather than the complete physical host configuration.

## Requirements

| Component | Requirement / suggested configuration |
| :--- | :--- |
| Computer | Compatible host with hardware virtualization support where required |
| Host RAM | 8 GB or more suggested for a comfortable desktop VM |
| Guest RAM | 4 GB suggested for Ubuntu Desktop |
| Virtual CPU | 2 vCPUs suggested, subject to host capacity |
| Virtual disk | 30 GB suggested, dynamically allocated VDI |
| Software | Oracle VirtualBox and compatible Ubuntu Desktop ISO |
| Network | Internet access for downloads and optional updates |

> [!NOTE]
> These are suggested settings, not measured specifications. Check the requirements and architecture compatibility of the selected Ubuntu release and VirtualBox version. A dynamically allocated disk grows as data is written, up to its configured capacity.

## System Architecture

```text
       ┌──────────────────────────────────────┐
       │  UBUNTU LINUX  •  GUEST TERMINAL      │
       │  $ uname -a                          │
       │  $ cat /etc/os-release               │
       └──────────────────┬───────────────────┘
                          │
                  ┌───────┴────────┐
                  │   VirtualBox   │
                  └───────┬────────┘
                          │
                  Physical computer
```

*Conceptual illustration — not an actual screenshot.*

```mermaid
flowchart TD
    A[Physical computer] --> B[Host operating system]
    B --> C[Oracle VirtualBox]
    C --> D[Ubuntu virtual machine]
    D --> E[Virtual CPU and RAM]
    D --> F[Virtual disk and network]
    D --> G[Ubuntu Linux kernel]
    G --> H[Terminal verification commands]
    classDef accent fill:#431407,stroke:#FBBF24,color:#ffffff
    class C,D,H accent
```

## Procedure

1. Download VirtualBox from the [official download page](https://www.virtualbox.org/wiki/Downloads) and install the appropriate host package.
2. Download a compatible Ubuntu Desktop ISO from the [official Ubuntu website](https://ubuntu.com/download/desktop).
3. Launch VirtualBox and select **New**.
4. Name the VM `Ubuntu Linux`, select the ISO and appropriate Linux/Ubuntu guest type. If offered, skip unattended installation to follow the manual installer.
5. Allocate RAM and virtual CPUs while leaving adequate resources for the host.
6. Create a virtual hard disk, preferably a dynamically allocated VDI. Confirm the ISO is attached to the virtual optical drive under Storage if not already attached.
7. Start the VM and follow the Ubuntu installer. Select language, keyboard, installation options, time zone and user credentials as prompted.
8. Select the virtual disk as the installation target. Complete installation, restart the VM and detach the ISO if prompted or if the installer starts again.
9. Log in to Ubuntu and open Terminal using `Ctrl + Alt + T` (Ubuntu Desktop default shortcut).
10. Execute the verification commands below and save actual outputs.

> [!IMPORTANT]
> Disk-erasure options in the Ubuntu installer should target only the newly created virtual disk. Do not attach a physical disk or select an unintended storage device.

```mermaid
flowchart TD
    A([Start]) --> B[Download VirtualBox and Ubuntu ISO]
    B --> C[Install VirtualBox]
    C --> D[Create and configure VM]
    D --> E[Attach ISO and boot]
    E --> F[Install Ubuntu]
    F --> G[Restart and log in]
    G --> H[Execute verification commands]
    H --> I{Commands successful?}
    I -->|Yes| J[Record actual observations]
    I -->|No| K[Troubleshoot errors]
    K --> H
    J --> L([End])
    classDef ember fill:#431407,stroke:#FBBF24,color:#ffffff
    class A,D,H,J,L ember
```

## Implementation

### Linux verification commands

Run these commands in the Ubuntu guest terminal:

```bash
uname -a
cat /etc/os-release
date
whoami
pwd
lscpu
free -h
df -h
ip addr
uname -r
```

| No. | Command | Expected information |
| ---: | :--- | :--- |
| 01 | `uname -a` | Kernel name, hostname, release, version and architecture |
| 02 | `cat /etc/os-release` | OS identification and release details |
| 03 | `date` | Current guest date, time and time zone |
| 04 | `whoami` | Effective current username |
| 05 | `pwd` | Current working directory |
| 06 | `lscpu` | CPU architecture and processor topology visible to guest |
| 07 | `free -h` | Human-readable RAM and swap statistics |
| 08 | `df -h` | Human-readable space usage of mounted filesystems |
| 09 | `ip addr` | Network interfaces and assigned addresses, if any |
| 10 | `uname -r` | Running Linux kernel release |

### Automated verification

Copy the Bash source section from [program.txt](program.txt) into a new file named `program.sh`. The script executes all ten commands, labels each output and reports command failures. No administrator privileges are required for normal execution.

```bash
bash program.sh
```

To save the actual output:

```bash
bash program.sh > verification-output.txt 2>&1
```

Alternatively, make the script executable and run it:

```bash
chmod +x program.sh
./program.sh
```

## Screenshot Documentation

```text
+----------------------------------+
| Ubuntu Terminal                  |
| $ uname -a                       |
| $ cat /etc/os-release            |
| $ lscpu                          |
| $ free -h                        |
+----------------------------------+
```
*Conceptual illustration, not a screenshot.*

*Illustration only — not a captured Ubuntu session.*

> [!NOTE]
> Screenshot placeholders below are not evidence of execution. Capture your own screenshots, save them with the indicated names in `screenshots/`, and uncomment the corresponding Markdown image lines. Redact sensitive information before publishing.

| Figure | Screenshot file | Annotation / evidence to highlight |
| :--- | :--- | :--- |
| 01 | `01-virtualbox.png` | VirtualBox Manager and New button |
| 02 | `02-vm-settings.png` | VM name, RAM, CPU and virtual disk |
| 03 | `03-iso-storage.png` | Ubuntu ISO attached to optical drive |
| 04 | `04-installation.png` | Ubuntu installer and selected virtual disk |
| 05 | `05-desktop.png` | Ubuntu desktop after successful reboot |
| 06 | `06-terminal.png` | OS identification and verification outputs |

<!-- Replace these placeholders with actual screenshots by uncommenting each line after adding the image files.
![Figure 01 — VirtualBox Manager](screenshots/01-virtualbox.png)
![Figure 02 — Virtual machine configuration](screenshots/02-vm-settings.png)
![Figure 03 — ISO attachment](screenshots/03-iso-storage.png)
![Figure 04 — Ubuntu installation](screenshots/04-installation.png)
![Figure 05 — Ubuntu desktop](screenshots/05-desktop.png)
![Figure 06 — Terminal verification](screenshots/06-terminal.png)
-->

### Existing screenshot references

The saved GitHub page references the following seven screenshots. Their image files were not included in the upload. Recover them from your original repository before embedding.

- `693171487-6a6645e0-5e69-4b6b-96d3-b9c644744b16.png`
- `693171413-754db201-8f47-4444-b895-d17c05530b26.png`
- `693171356-d2623291-b955-4e1a-be04-2b707b04df8b.png`
- `693171328-826e8045-3a44-4882-9d3f-da9aaf4502f9.png`
- `693171300-4ee29245-c4cc-4694-8e7b-35e935089d2e.png`
- `693171269-a3c5d437-da8b-448b-8ab3-fa7684be2ef1.png`
- `693171103-adea700b-246a-4325-a15e-39ba9be89525.png`

## Experimental Observations

Record actual values from the guest after running the commands.

| Parameter | Actual observation | Status |
| :--- | :--- | :--- |
| System information | [uname -a output] | Pending evidence |
| Ubuntu release | [PRETTY_NAME value] | Pending evidence |
| Date and time | [date output] | Pending evidence |
| Current user | [whoami output] | Pending evidence |
| Working directory | [pwd output] | Pending evidence |
| CPU | [lscpu summary] | Pending evidence |
| RAM and swap | [free -h output] | Pending evidence |
| Disk space | [df -h output] | Pending evidence |
| Network | [ip addr summary] | Pending evidence |
| Kernel release | [uname -r output] | Pending evidence |

## Results

**Reported result:** Oracle VirtualBox and Ubuntu Linux are configured and verified in a virtualized environment, as stated in the supplied experiment record.

**Evidence status:** Actual command outputs and screenshot image files could not be inspected in the supplied saved HTML. Complete the observation table to substantiate the reported result.

Acceptance criteria:

- [ ] VirtualBox installed and VM configured.
- [ ] Ubuntu boots from the virtual hard disk after installation.
- [ ] Ubuntu release and kernel information verified.
- [ ] All ten verification commands executed and outputs recorded.
- [ ] Screenshots attached to the repository.

## Troubleshooting

| Issue | Possible cause | Corrective action |
| :--- | :--- | :--- |
| VM fails to start | Virtualization unavailable or host compatibility issue | Check firmware virtualization settings and VirtualBox host requirements. |
| No bootable medium | ISO not attached or incorrect boot order | Attach a compatible ISO and check boot order. |
| Slow guest | Insufficient resources or host overload | Adjust RAM and CPU within available host capacity. |
| Installer starts again | ISO still attached | Eject the virtual optical disk and boot from virtual hard disk. |
| No network connection | Virtual adapter disconnected or misconfigured | Check adapter enabled, cable connected and NAT settings. |
| Command not found | Utility missing | Check spelling and install the relevant package if required (e.g. `iproute2` for `ip`). |
| Disk full | Insufficient guest filesystem capacity | Inspect `df -h`; free space or safely expand virtual disk and guest filesystem. |

## Conclusion

The experiment illustrates how Ubuntu can be installed and operated independently of the host OS using VirtualBox. The verification commands provide practical insight into Linux system identity, CPU, memory, storage, networking and kernel information. Successful completion is established by the recorded installation and terminal evidence.

## Repository Structure

```text
experiment-01/
├── README.md
├── experiment.txt
├── program.txt
├── verification-output.txt   # Generated after execution
└── screenshots/             # Add actual screenshots
    ├── 01-virtualbox.png
    ├── 02-vm-settings.png
    ├── 03-iso-storage.png
    ├── 04-installation.png
    ├── 05-desktop.png
    └── 06-terminal.png
```

## References

- [Oracle VirtualBox downloads](https://www.virtualbox.org/wiki/Downloads)
- [VirtualBox documentation](https://www.virtualbox.org/wiki/Documentation)
- [Ubuntu Desktop downloads](https://ubuntu.com/download/desktop)
- [Ubuntu documentation](https://help.ubuntu.com/)
- Linux manual pages: `man uname`, `man lscpu`, `man free`, `man df`, `man ip`.

---

<div align="center">

![Footer](https://capsule-render.vercel.app/api?type=waving&color=0:171717,100:E95420&height=100&section=footer)

**OPERATING SYSTEMS LABORATORY · EXPERIMENT 01**

Virtualization | Ubuntu Linux | Bash

</div>
